define([], function() {
  return TYPO3.settings.formlog || {};
});
